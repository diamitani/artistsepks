---
name: generate-design-system
description: Resolves a concrete design system (palette, typography, layout grid, section order) for the final EPK based on the selected template (One Sheeter, General, Booking, Media, Brand) and any supplied brand assets. Use after compile-data, before final EPK rendering.
---

# Generate Design System

## Purpose
Resolve a concrete design system (palette, typography, layout grid, section order) for the final EPK based
on the selected template and any brand assets/guidelines supplied.

## When to use this skill
Use once template selection is known (from intake or default) and `enhanced.md` exists.

## Inputs
The EPK template library reference, the EPK design tokens reference, brand assets/brand guidelines from
`master.md` → `## Media & Uploads`, and the template choice (One Sheeter, General, Booking, Media, Brand).

## Procedure
1. Load the base token set for the selected template family.
2. If the artist supplied brand assets (logo, brand guideline doc, color palette), extract dominant colors
   and any stated brand fonts/voice, and override the template's default palette/type with the artist's
   brand where provided — template structure (layout/section order) stays fixed, brand identity overrides
   surface styling.
3. Resolve final tokens: color palette (primary/secondary/accent/background/text), type scale (display,
   heading, body), spacing/grid rules, and section order for the chosen template.
4. Record every override decision and its source (brand asset vs. template default).

## Output
`epk-design-system.json` — resolved token set, section order, and provenance notes.

## Guardrails
Never invent a brand color/font not evidenced by supplied assets — fall back to the template default and
note the assumption. Section order/required sections come from the template spec and are not
user-overridable without an explicit request.

## Default template families
- **One Sheeter** — single-page, high-density pitch summary.
- **General** — default, all-purpose press kit (used when no template is specified).
- **Booking** — booker-first ordering; surfaces performance history and riders above general bio depth.
- **Media** — editorial, photo-forward, press-narrative emphasis.
- **Brand** — data/visual-forward, emphasizes brand identity and audience data for sponsorship pitches.
