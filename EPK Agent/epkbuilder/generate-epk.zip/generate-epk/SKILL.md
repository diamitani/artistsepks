---
name: generate-epk
description: Renders the final Electronic Press Kit as HTML and PDF using the generated bios, enhanced.md, and resolved design system, with optional Canva polishing and Vercel deployment gated behind approval. Use as the final step once bios and the design system are both generated.
---

# Generate EPK

## Purpose
Render the final EPK using the generated bios, `enhanced.md`, and the resolved design system, output as
HTML and PDF, and optionally deploy the HTML build.

## When to use this skill
Use once `bio-long.md`, `bio-short.md`, and `epk-design-system.json` all exist and reference the same
`enhanced.md` version. This is always the last skill run in the EPK pipeline.

## Inputs
`bio-long.md`, `bio-short.md`, `enhanced.md`, `epk-design-system.json`, and the EPK template library
reference.

## Procedure
1. Populate the template's section layout with: hero (artist name, tagline/short bio, hero image), long
   bio, genre/style/theme analysis, discography (table + cover art), social & engagement score (with
   disclosure of formula/recency), press/"as seen in," collaborations & performances, contact &
   representation, riders (if Booking template), and media assets gallery.
2. Render `epk.html` using the resolved design system tokens; if the user requested a Canva-polished
   output, hand the same content and tokens to the Canva MCP renderer and use its export as the final
   HTML/PDF source instead.
3. Render `epk.pdf` from the same populated content, preserving section order and design tokens for visual
   consistency between HTML and PDF.
4. Run a final consistency check: every number/claim in the rendered output still matches its source in
   `enhanced.md`; no `[MISSING: ...]` marker was silently dropped — genuinely missing fields should render
   as omitted sections, not as fabricated filler.
5. If the user requests deployment, package `epk.html` for Vercel and request explicit approval before
   executing the production deploy — never deploy to production without an approval record. Preview deploys
   do not require approval.

## Output
`epk.html`, `epk.pdf`, and (if approved) a live Vercel deployment URL.

## Guardrails
This is the only skill allowed to produce the final `epk.html`/`epk.pdf`. Any content gap must be visibly
handled (e.g., section omitted or marked "coming soon") rather than invented. Rendering to file needs no
approval; deploying to a public production URL does.
