---
name: extract-music-metadata
description: Extracts structured metadata (title, release date, duration, ISRC/UPC, featured artists, cover art) from music links on Spotify, Apple Music, SoundCloud, YouTube, Pandora, and Suno via Composio MCP or public link extraction. Use after format-inputs to seed the artist's discography from platform links found in master.md.
---

# Extract Music Metadata

## Purpose
Extract structured metadata from every submitted music link to seed the discography.

## When to use this skill
Use after `format-inputs` has produced `master.md`, when it contains at least one platform link (Spotify,
Apple Music, SoundCloud, YouTube, Pandora, Suno).

## Inputs
Platform links from `master.md` → `## Platform Links` section.

## Procedure
1. For each link, resolve platform via URL pattern, then call the matching Composio MCP toolkit (Spotify,
   Apple Music, SoundCloud, YouTube Data API, Pandora) or a public link-extraction tool if no toolkit is
   connected for that platform.
2. Extract per track/release: title, release date, duration, ISRC/UPC if available, featured artists, album
   or EP name, cover art URL, platform-specific play/stream count if publicly exposed.
3. Deduplicate the same release appearing across multiple platforms into one logical entry with per-platform
   links attached.
4. Record extraction method and timestamp per entry (`source_platform`, `retrieved_at`, `extraction_method:
   api | scrape`).
5. If a link fails to resolve or the platform has no public API access, mark that entry
   `status: unresolved` and continue — do not block the rest of the batch.

## Output
`discography-raw.json` — array of release objects with full metadata and provenance, one entry per unique
release, with `confidence` per entry (1.0 for API-sourced, 0.6 for scraped, 0.0 for unresolved).

## Guardrails
Never estimate a stream/play count that isn't directly exposed by the platform. Never merge two distinct
releases into one entry without matching on title + release date + duration. Read-only access only — never
write, comment, or modify anything on the connected platform account.
