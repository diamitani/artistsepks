---
name: extract-social-media-data
description: Pulls follower/subscriber counts, post counts, and comment/like/share engagement from Instagram, TikTok, YouTube, X.com, and Facebook links via Composio MCP, with retrieval timestamps and confidence levels. Use after format-inputs to gather the raw social metrics needed for the engagement score and EPK stats.
---

# Extract Social Media Data

## Purpose
Pull follower counts, post counts, comment counts, and share/like metrics from every submitted social
platform link.

## When to use this skill
Use after `format-inputs` has produced `master.md`, when it contains at least one social link (Instagram,
TikTok, YouTube, Facebook, X.com).

## Inputs
Social links from `master.md` → `## Platform Links` section.

## Procedure
1. For each social link, call the matching Composio MCP toolkit (Instagram, TikTok, YouTube Data API,
   X.com, Facebook) using read-only profile/content scopes.
2. Extract, per platform: follower/subscriber count, total post/video count, average and most-recent-N-post
   engagement (likes, comments, shares/reposts, views where exposed), account creation date if available,
   and verification status if exposed.
3. Timestamp every extraction (`retrieved_at`) — social metrics are point-in-time and must never be
   presented as static facts without a retrieval date.
4. If a platform has no connected Composio auth, fall back to public link extraction for visible counts
   only; mark these `extraction_method: public-scrape`, `confidence: 0.5`.
5. If a platform blocks access entirely (private account, rate-limited, geo-blocked), mark
   `status: unresolved` and continue.

## Output
`social-media-raw.json` — one object per platform with all extracted fields, `retrieved_at`,
`extraction_method`, and `confidence`.

## Guardrails
Never average or extrapolate a metric across platforms to fill a missing one. Never present a follower
count without its retrieval date in the downstream artifact. Read-only access only.
